﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace mvccore_ajax_demo.Migrations
{
    /// <inheritdoc />
    public partial class FixStudentID : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
