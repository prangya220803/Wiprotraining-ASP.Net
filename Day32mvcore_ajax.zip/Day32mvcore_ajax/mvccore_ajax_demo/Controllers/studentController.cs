using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mvccore_ajax_demo.Models;
namespace mvccore_ajax_demo.Controllers;
public class studentController : Controller
{
    private readonly StudentContext _context;
    public studentController(StudentContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        return View();
    }
    [HttpPost]
    //public ActionResult createStudent(Student std)
    //{
    //context.Students.Add(std);
    //context.SaveChanges();
    //string message = "SUCCESS";
    //return Json(new { Message = message, JsonRequestBehavior.AllowGet });
    //}
    //public JsonResult getStudent(string id)
    //{
    //List<Student> students = new List<Student>();
    //students = context.Students.ToList();
    //return Json(students, JsonRequestBehavior.AllowGet);
    //}
    //public IActionResult CreateStudent(Student std)
    //{
    //_context.Students.Add(std);
    //_context.SaveChanges();
    //string message = "SUCCESS";
    //return Json(new { Message = message });   // JsonRequestBehavior hata do
    //}
public IActionResult CreateStudent([FromBody]Student std)
{
    _context.Students.Add(std);
    _context.SaveChanges();
    return Json(new { Message = "SUCCESS", StudentID = std.studentID }); // Database generated ID bhi bhej rahe
}

    [HttpGet]
    public IActionResult GetStudent(string id)
    {
        var students = _context.Students.ToList();
        return Json(students);   // JsonRequestBehavior hata do
    }

    
}