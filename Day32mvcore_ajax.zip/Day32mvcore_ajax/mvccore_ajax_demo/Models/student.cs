using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;  // required for DatabaseGenerated


namespace mvccore_ajax_demo.Models
{
    public class Student
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)] // Add this line
        public int studentID { get; set; }
        [Required]
        public string studentName { get; set; }

        [Required]
        public string studentAddress { get; set; }

    }
}