namespace MiniShop.Models
{
    public static class SessionKeys
    {
        public const string UserName = "UserName"; // 👈 ye hamesha same use karna
        public const string Cart = "Cart";
    }
}